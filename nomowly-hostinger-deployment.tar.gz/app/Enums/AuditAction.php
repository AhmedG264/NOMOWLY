<?php

namespace App\Enums;

enum AuditAction: string
{
    // Authentication & Identity
    case LOGIN_SUCCESS = 'LOGIN_SUCCESS';
    case LOGIN_FAILED = 'LOGIN_FAILED';
    case LOGOUT = 'LOGOUT';
    case REGISTER_BRAND = 'REGISTER_BRAND';
    case REGISTER_MARKETER = 'REGISTER_MARKETER';
    case PASSWORD_CHANGE = 'PASSWORD_CHANGE';
    case PASSWORD_RESET_REQUEST = 'PASSWORD_RESET_REQUEST';
    case PASSWORD_RESET_COMPLETE = 'PASSWORD_RESET_COMPLETE';
    case EMAIL_VERIFIED = 'EMAIL_VERIFIED';
    case SUPER_ADMIN_BOOTSTRAP = 'SUPER_ADMIN_BOOTSTRAP';
    case USER_PROFILE_UPDATED = 'USER_PROFILE_UPDATED';
    case USER_STATUS_CHANGED = 'USER_STATUS_CHANGED';

    // Security & Authorization
    case UNAUTHORIZED_ACCESS_ATTEMPT = 'UNAUTHORIZED_ACCESS_ATTEMPT';
    case ADMIN_SETTINGS_CHANGED = 'ADMIN_SETTINGS_CHANGED';
    case ROLE_CREATED = 'ROLE_CREATED';
    case ROLE_UPDATED = 'ROLE_UPDATED';
    case ROLE_DELETED = 'ROLE_DELETED';
    case PERMISSIONS_ASSIGNED = 'PERMISSIONS_ASSIGNED';
    case USER_ROLES_ASSIGNED = 'USER_ROLES_ASSIGNED';

    // Campaigns & Applications
    case CAMPAIGN_CREATED = 'CAMPAIGN_CREATED';
    case CAMPAIGN_UPDATED = 'CAMPAIGN_UPDATED';
    case CAMPAIGN_STATUS_CHANGED = 'CAMPAIGN_STATUS_CHANGED';
    case CAMPAIGN_APPLICATION_SUBMITTED = 'CAMPAIGN_APPLICATION_SUBMITTED';
    case CAMPAIGN_APPLICATION_APPROVED = 'CAMPAIGN_APPLICATION_APPROVED';
    case CAMPAIGN_APPLICATION_REJECTED = 'CAMPAIGN_APPLICATION_REJECTED';

    // Attribution & Conversions
    case ATTRIBUTION_CLICK_RECORDED = 'ATTRIBUTION_CLICK_RECORDED';
    case CONVERSION_RECEIVED = 'CONVERSION_RECEIVED';
    case CONVERSION_ATTRIBUTED = 'CONVERSION_ATTRIBUTED';
    case CONVERSION_APPROVED = 'CONVERSION_APPROVED';
    case CONVERSION_REJECTED = 'CONVERSION_REJECTED';
    case CONVERSION_CANCELLED = 'CONVERSION_CANCELLED';
    case COMMISSION_CALCULATED = 'COMMISSION_CALCULATED';

    // Phase 4: Wallets & Double-Entry Ledger
    case WALLET_CREATED = 'WALLET_CREATED';
    case WALLET_STATUS_CHANGED = 'WALLET_STATUS_CHANGED';
    case LEDGER_TRANSACTION_POSTED = 'LEDGER_TRANSACTION_POSTED';
    case LEDGER_TRANSACTION_REVERSED = 'LEDGER_TRANSACTION_REVERSED';
    case BUDGET_RESERVED = 'BUDGET_RESERVED';
    case BUDGET_RELEASED = 'BUDGET_RELEASED';
    case FINANCIAL_ADJUSTMENT = 'FINANCIAL_ADJUSTMENT';

    // Phase 5A: Commission Settlement & Payout Requests
    case COMMISSION_SETTLED = 'COMMISSION_SETTLED';
    case COMMISSION_SETTLEMENT_REVERSED = 'COMMISSION_SETTLEMENT_REVERSED';
    case PAYOUT_REQUESTED = 'PAYOUT_REQUESTED';
    case PAYOUT_APPROVED = 'PAYOUT_APPROVED';
    case PAYOUT_REJECTED = 'PAYOUT_REJECTED';
    case PAYOUT_PAID = 'PAYOUT_PAID';

    /**
     * Human-readable Arabic label for the audit action.
     */
    public function label(): string
    {
        return match ($this) {
            self::LOGIN_SUCCESS => 'تسجيل دخول ناجح',
            self::LOGIN_FAILED => 'محاولة دخول فاشلة',
            self::LOGOUT => 'تسجيل خروج',
            self::REGISTER_BRAND => 'تسجيل علامة تجارية جديدة',
            self::REGISTER_MARKETER => 'تسجيل مسوق / صانع محتوى',
            self::PASSWORD_CHANGE => 'تغيير كلمة المرور',
            self::PASSWORD_RESET_REQUEST => 'طلب استعادة كلمة المرور',
            self::PASSWORD_RESET_COMPLETE => 'إتمام إعادة تعيين كلمة المرور',
            self::EMAIL_VERIFIED => 'تأكيد البريد الإلكتروني',
            self::SUPER_ADMIN_BOOTSTRAP => 'تهيئة حساب المدير العام',
            self::USER_PROFILE_UPDATED => 'تحديث بيانات المستخدم',
            self::USER_STATUS_CHANGED => 'تغيير حالة حساب المستخدم',

            self::UNAUTHORIZED_ACCESS_ATTEMPT => 'محاولة وصول غير مصرح بها',
            self::ADMIN_SETTINGS_CHANGED => 'تعديل إعدادات النظام الإدارية',
            self::ROLE_CREATED => 'إنشاء دور إداري جديد',
            self::ROLE_UPDATED => 'تعديل بيانات الدور الإداري',
            self::ROLE_DELETED => 'حذف دور إداري',
            self::PERMISSIONS_ASSIGNED => 'تحديث صلاحيات الدور الإداري',
            self::USER_ROLES_ASSIGNED => 'إسناد وتعديل أدوار المستخدم',

            self::CAMPAIGN_CREATED => 'إنشاء حملة تسويقية جديدة',
            self::CAMPAIGN_UPDATED => 'تحديث بيانات حملة تسويقية',
            self::CAMPAIGN_STATUS_CHANGED => 'تغيير حالة الحملة التسويقية',
            self::CAMPAIGN_APPLICATION_SUBMITTED => 'تقديم طلب مشاركة بحملة',
            self::CAMPAIGN_APPLICATION_APPROVED => 'اعتماد مسوق في الحملة',
            self::CAMPAIGN_APPLICATION_REJECTED => 'رفض طلب مسوق في الحملة',

            self::ATTRIBUTION_CLICK_RECORDED => 'تسجيل نقرة إحالة ترويجية',
            self::CONVERSION_RECEIVED => 'استقبال تحويل مبيعات (طلب خارجي)',
            self::CONVERSION_ATTRIBUTED => 'إسناد تحويل مبيعات لمسوق معتمد',
            self::CONVERSION_APPROVED => 'اعتماد تحويل مبيعات وعمولة',
            self::CONVERSION_REJECTED => 'رفض تحويل مبيعات',
            self::CONVERSION_CANCELLED => 'إلغاء تحويل مبيعات معتمد مسبقاً',
            self::COMMISSION_CALCULATED => 'احتساب قيمة العمولة التسويقية',

            self::WALLET_CREATED => 'إنشاء محفظة مالية جديدة',
            self::WALLET_STATUS_CHANGED => 'تغيير حالة المحفظة المالية',
            self::LEDGER_TRANSACTION_POSTED => 'ترحيل معاملة دفتر أستاذ محاسبي',
            self::LEDGER_TRANSACTION_REVERSED => 'عكس معاملة دفتر أستاذ (قيد تسوية)',
            self::BUDGET_RESERVED => 'حجز ميزانية حملة في المحفظة',
            self::BUDGET_RELEASED => 'تحرير ميزانية محجوزة للحملة',
            self::FINANCIAL_ADJUSTMENT => 'تسوية مالية إدارية مسجلة',

            self::COMMISSION_SETTLED => 'تسوية وصرف عمولة تحويل للمسوق',
            self::COMMISSION_SETTLEMENT_REVERSED => 'عكس تسوية عمولة تحويل ملغي',
            self::PAYOUT_REQUESTED => 'تقديم طلب سحب أرباح للمسوق',
            self::PAYOUT_APPROVED => 'اعتماد طلب سحب أرباح المسوق',
            self::PAYOUT_REJECTED => 'رفض طلب سحب أرباح وإعادة الرصيد',
            self::PAYOUT_PAID => 'تأكيد تحويل وصرف أرباح المسوق',
        };
    }

    /**
     * Category grouping for filtering in the audit UI.
     */
    public function category(): string
    {
        return match ($this) {
            self::LOGIN_SUCCESS, self::LOGIN_FAILED, self::LOGOUT,
            self::REGISTER_BRAND, self::REGISTER_MARKETER,
            self::PASSWORD_CHANGE, self::PASSWORD_RESET_REQUEST,
            self::PASSWORD_RESET_COMPLETE, self::EMAIL_VERIFIED,
            self::SUPER_ADMIN_BOOTSTRAP, self::USER_PROFILE_UPDATED,
            self::USER_STATUS_CHANGED => 'الهوية والمستخدمين',

            self::UNAUTHORIZED_ACCESS_ATTEMPT, self::ADMIN_SETTINGS_CHANGED,
            self::ROLE_CREATED, self::ROLE_UPDATED, self::ROLE_DELETED,
            self::PERMISSIONS_ASSIGNED, self::USER_ROLES_ASSIGNED => 'الأدوار والصلاحيات والأمان',

            self::CAMPAIGN_CREATED, self::CAMPAIGN_UPDATED,
            self::CAMPAIGN_STATUS_CHANGED, self::CAMPAIGN_APPLICATION_SUBMITTED,
            self::CAMPAIGN_APPLICATION_APPROVED,
            self::CAMPAIGN_APPLICATION_REJECTED => 'الحملات والمشاركات',

            self::ATTRIBUTION_CLICK_RECORDED, self::CONVERSION_RECEIVED,
            self::CONVERSION_ATTRIBUTED, self::CONVERSION_APPROVED,
            self::CONVERSION_REJECTED, self::CONVERSION_CANCELLED,
            self::COMMISSION_CALCULATED => 'التتبع والتحويلات',

            self::WALLET_CREATED, self::WALLET_STATUS_CHANGED,
            self::LEDGER_TRANSACTION_POSTED, self::LEDGER_TRANSACTION_REVERSED,
            self::BUDGET_RESERVED, self::BUDGET_RELEASED,
            self::FINANCIAL_ADJUSTMENT, self::COMMISSION_SETTLED,
            self::COMMISSION_SETTLEMENT_REVERSED, self::PAYOUT_REQUESTED,
            self::PAYOUT_APPROVED, self::PAYOUT_REJECTED,
            self::PAYOUT_PAID => 'المالية ودفتر القيود المحاسبية',
        };
    }

    /**
     * Badge CSS class for the audit action.
     */
    public function badgeClass(): string
    {
        return match ($this) {
            self::LOGIN_SUCCESS, self::CAMPAIGN_APPLICATION_APPROVED,
            self::CONVERSION_APPROVED, self::LEDGER_TRANSACTION_POSTED,
            self::WALLET_CREATED, self::COMMISSION_SETTLED,
            self::PAYOUT_PAID => 'bg-emerald-50 text-emerald-700 border-emerald-200',

            self::LOGIN_FAILED, self::CAMPAIGN_APPLICATION_REJECTED,
            self::CONVERSION_REJECTED, self::PAYOUT_REJECTED,
            self::UNAUTHORIZED_ACCESS_ATTEMPT => 'bg-rose-50 text-rose-700 border-rose-200',

            self::ROLE_CREATED, self::ROLE_UPDATED, self::PERMISSIONS_ASSIGNED, self::USER_ROLES_ASSIGNED,
            self::CAMPAIGN_CREATED, self::REGISTER_BRAND,
            self::REGISTER_MARKETER, self::BUDGET_RELEASED,
            self::PAYOUT_APPROVED => 'bg-blue-50 text-blue-700 border-blue-200',

            self::CAMPAIGN_UPDATED, self::USER_PROFILE_UPDATED,
            self::CAMPAIGN_STATUS_CHANGED, self::BUDGET_RESERVED,
            self::PASSWORD_CHANGE, self::PAYOUT_REQUESTED => 'bg-amber-50 text-amber-700 border-amber-200',

            self::CONVERSION_CANCELLED, self::WALLET_STATUS_CHANGED,
            self::FINANCIAL_ADJUSTMENT => 'bg-slate-100 text-slate-700 border-slate-300',

            self::LEDGER_TRANSACTION_REVERSED,
            self::COMMISSION_SETTLEMENT_REVERSED => 'bg-purple-50 text-purple-700 border-purple-200',

            default => 'bg-purple-50 text-purple-700 border-purple-200',
        };
    }
}
