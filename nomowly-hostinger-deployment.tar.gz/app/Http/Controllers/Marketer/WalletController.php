<?php

namespace App\Http\Controllers\Marketer;

use App\Enums\Currency;
use App\Enums\PayoutRequestStatus;
use App\Http\Controllers\Controller;
use App\Models\CommissionSettlement;
use App\Models\PayoutRequest;
use App\Models\Wallet;
use App\Services\Ledger\PayoutService;
use App\Services\Ledger\WalletService;
use App\Services\Math\MoneyMath;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class WalletController extends Controller
{
    public function __construct(
        protected WalletService $walletService,
        protected PayoutService $payoutService
    ) {}

    /**
     * Display marketer's multi-currency wallets, settlements, and payout requests.
     */
    public function index(Request $request): View
    {
        $user = $request->user();
        $marketerProfile = $user->marketerProfile;
        abort_unless($marketerProfile, 403, 'الملف الشخصي للمسوق غير مكتمل.');

        // Fetch or initialize wallets for supported currencies
        $currencies = Currency::cases();
        $wallets = [];

        foreach ($currencies as $curr) {
            $wallets[$curr->value] = $this->walletService->getOrCreateWallet($user, $curr);
        }

        // Payout Requests for this marketer
        $payoutRequests = PayoutRequest::where('user_id', $user->id)
            ->with(['reviewer', 'payer', 'wallet'])
            ->latest('created_at')
            ->paginate(15, ['*'], 'payouts_page')
            ->withQueryString();

        // Commission Settlements earned by this marketer
        $settlements = CommissionSettlement::whereHas('conversion.campaignApplication', function ($q) use ($marketerProfile) {
            $q->where('marketer_profile_id', $marketerProfile->id);
        })
            ->with(['conversion.campaign', 'ledgerTransaction'])
            ->latest('settled_at')
            ->paginate(15, ['*'], 'settlements_page')
            ->withQueryString();

        // Calculate summary across wallets
        $totalAvailableSAR = '0.0000';
        $totalPendingPayoutSAR = '0.0000';

        foreach ($wallets as $code => $wallet) {
            if ($code === 'SAR') {
                $totalAvailableSAR = MoneyMath::format($wallet->available_balance);
                $totalPendingPayoutSAR = MoneyMath::format($wallet->reserved_balance);
            }
        }

        return view('marketer.wallet.index', [
            'wallets' => $wallets,
            'currencies' => $currencies,
            'payoutRequests' => $payoutRequests,
            'settlements' => $settlements,
            'totalAvailableSAR' => $totalAvailableSAR,
            'totalPendingPayoutSAR' => $totalPendingPayoutSAR,
        ]);
    }

    /**
     * Submit a payout request from a specific currency wallet.
     */
    public function storePayoutRequest(Request $request): RedirectResponse
    {
        $user = $request->user();
        $marketerProfile = $user->marketerProfile;
        abort_unless($marketerProfile, 403, 'الملف الشخصي للمسوق غير مكتمل.');

        $validated = $request->validate([
            'wallet_id' => ['required', 'uuid', 'exists:wallets,id'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'bank_name' => ['required', 'string', 'min:3', 'max:100'],
            'account_holder_name' => ['required', 'string', 'min:3', 'max:120'],
            'account_reference' => ['required', 'string', 'min:8', 'max:50'],
        ], [
            'wallet_id.required' => 'يرجى اختيار المحفظة المراد سحب الأرباح منها.',
            'amount.required' => 'يرجى تحديد المبلغ المراد سحبه.',
            'amount.gt' => 'يجب أن يكون مبلغ السحب أكبر من صفر.',
            'bank_name.required' => 'اسم البنك إلزامي لإتمام التحويل.',
            'account_holder_name.required' => 'اسم صاحب الحساب البنكي إلزامي.',
            'account_reference.required' => 'رقم الآيبان (IBAN) أو الحساب البنكي إلزامي.',
            'account_reference.min' => 'رقم الحساب أو الآيبان قصير جداً.',
        ]);

        $wallet = Wallet::where('id', $validated['wallet_id'])
            ->where('user_id', $user->id)
            ->firstOrFail();

        $amountStr = MoneyMath::format($validated['amount']);

        try {
            $payoutRequest = $this->payoutService->createPayoutRequest(
                $user,
                $wallet,
                $amountStr,
                [
                    'bank_name' => trim($validated['bank_name']),
                    'account_holder_name' => trim($validated['account_holder_name']),
                    'account_reference' => trim($validated['account_reference']),
                    'idempotency_key' => 'payout-req-' . $user->id . '-' . Str::random(16),
                ]
            );

            return redirect()->route('marketer.wallet.index')->with(
                'status',
                "تم تقديم طلب سحب الأرباح رقم [{$payoutRequest->request_number}] بمبلغ {$amountStr} {$wallet->currency->value} بنجاح، وتم حجز المبلغ بانتظار المراجعة والتحويل البنكي."
            );
        } catch (\Throwable $e) {
            return back()->withInput()->withErrors([
                'amount' => $e->getMessage(),
            ]);
        }
    }
}
