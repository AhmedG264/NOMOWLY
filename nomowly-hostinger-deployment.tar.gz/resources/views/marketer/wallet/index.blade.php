@extends('layouts.app')

@section('content')
<div class="py-8 sm:py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8" x-data="{ payoutModalOpen: false, selectedWalletId: '', selectedCurrency: 'SAR', maxAvailable: '0.00' }">
    <!-- Header Banner -->
    <div class="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-teal-900/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold mb-3 border border-teal-400/30">
                <span>💳</span>
                <span>المحفظة المالية والأرباح المستحقة • Marketer Wallet & Payouts</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black tracking-tight">محفظتي وأرباح التسويق</h1>
            <p class="text-slate-400 text-xs sm:text-sm mt-1">
                إدارة أرباحك وعمولاتك المؤكدة من الحملات، متابعة الرصيد المتاح، وتقديم طلبات سحب الأرباح لحسابك البنكي.
            </p>
        </div>
        <div class="flex items-center gap-3">
            <a href="{{ route('marketer.campaigns.index') }}" class="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs sm:text-sm font-bold border border-white/20 transition">
                ← حملاتي وأكواد التتبع
            </a>
            <a href="{{ route('marketer.dashboard') }}" class="px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs sm:text-sm font-black shadow-md transition">
                لوحة التحكم
            </a>
        </div>
    </div>

    <!-- Feedback Alerts -->
    @if (session('status'))
        <div class="rounded-2xl bg-emerald-50 border border-emerald-200 p-4 text-sm text-emerald-800 font-bold flex items-center gap-2">
            <span class="text-emerald-500 font-black">✓</span>
            <span>{{ session('status') }}</span>
        </div>
    @endif

    @if ($errors->any())
        <div class="rounded-2xl bg-rose-50 border border-rose-200 p-4 text-sm text-rose-800 font-bold space-y-1">
            <div class="flex items-center gap-2">
                <span class="text-rose-600 font-black">✕</span>
                <span>حدث خطأ أثناء معالجة الطلب:</span>
            </div>
            <ul class="list-disc list-inside text-xs font-medium text-rose-700">
                @foreach ($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Wallets Cards Grid -->
    <div>
        <div class="flex items-center justify-between mb-4">
            <div>
                <h2 class="text-lg font-black text-slate-900">أرصدة المحافظ بالعملات المختلفة</h2>
                <p class="text-xs text-slate-500">لكل عملة محفظة محاسبية منفصلة ومعزولة تماماً لمنع تقلبات أسعار الصرف</p>
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            @foreach ($currencies as $curr)
                @php
                    $wallet = $wallets[$curr->value] ?? null;
                    $avail = $wallet ? \App\Services\Math\MoneyMath::format($wallet->available_balance) : '0.0000';
                    $reserved = $wallet ? \App\Services\Math\MoneyMath::format($wallet->reserved_balance) : '0.0000';
                    $hasBalance = \App\Services\Math\MoneyMath::isPositive($avail);
                @endphp
                <div class="bg-white rounded-3xl border {{ $hasBalance ? 'border-teal-300 ring-2 ring-teal-500/10' : 'border-slate-200/80' }} p-5 shadow-xs flex flex-col justify-between space-y-4">
                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-black bg-slate-100 text-slate-800">
                                <span>{{ $curr->symbol() }}</span>
                                <span>{{ $curr->value }}</span>
                            </span>
                            <span class="text-[11px] font-bold text-slate-400">{{ $curr->label() }}</span>
                        </div>

                        <div class="space-y-1">
                            <div class="text-xs text-slate-500 font-medium">الرصيد المتاح للسحب</div>
                            <div class="text-2xl font-black text-slate-900 tracking-tight">
                                {{ \App\Services\Math\MoneyMath::display($avail, $curr->value) }}
                                <span class="text-xs font-bold text-slate-400">{{ $curr->value }}</span>
                            </div>
                        </div>

                        @if (\App\Services\Math\MoneyMath::isPositive($reserved))
                            <div class="mt-2 pt-2 border-t border-slate-100 text-[11px] text-amber-600 font-medium flex items-center justify-between">
                                <span>معلق بطلب سحب:</span>
                                <span class="font-bold">{{ \App\Services\Math\MoneyMath::display($reserved, $curr->value) }}</span>
                            </div>
                        @endif
                    </div>

                    <div>
                        @if ($wallet && $hasBalance)
                            <button type="button"
                                    @click="payoutModalOpen = true; selectedWalletId = '{{ $wallet->id }}'; selectedCurrency = '{{ $curr->value }}'; maxAvailable = '{{ $avail }}'"
                                    class="w-full py-2 px-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-black transition shadow-xs cursor-pointer flex items-center justify-center gap-1.5">
                                <span>💸</span>
                                <span>طلب سحب أرباح</span>
                            </button>
                        @else
                            <button type="button" disabled
                                    class="w-full py-2 px-3 bg-slate-100 text-slate-400 rounded-xl text-xs font-bold cursor-not-allowed">
                                لا يوجد رصيد متاح
                            </button>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Payout Request Modal -->
    <div x-show="payoutModalOpen"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
         style="display: none;">
        <div @click.away="payoutModalOpen = false"
             class="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 text-right space-y-6">
            <div class="flex items-center justify-between border-b border-slate-100 pb-4">
                <div class="flex items-center gap-2">
                    <span class="w-10 h-10 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center text-lg font-black">💸</span>
                    <div>
                        <h3 class="text-base font-black text-slate-900">طلب سحب أرباح مصرفي</h3>
                        <p class="text-xs text-slate-500">عملة السحب: <span class="font-bold text-teal-600" x-text="selectedCurrency"></span></p>
                    </div>
                </div>
                <button type="button" @click="payoutModalOpen = false" class="text-slate-400 hover:text-slate-600 text-xl font-bold cursor-pointer">✕</button>
            </div>

            <form method="POST" action="{{ route('marketer.wallet.payout-request') }}" class="space-y-4">
                @csrf
                <input type="hidden" name="wallet_id" :value="selectedWalletId">

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">
                        المبلغ المطلوب سحبه (<span x-text="selectedCurrency"></span>) *
                    </label>
                    <div class="relative">
                        <input type="number" step="any" name="amount" required min="1" :max="maxAvailable"
                               placeholder="أدخل المبلغ المطلوب"
                               class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-bold focus:ring-2 focus:ring-teal-500 focus:outline-none">
                    </div>
                    <p class="text-[11px] text-slate-500 mt-1">
                        الحد الأقصى المتاح حالياً: <span class="font-bold text-slate-800" x-text="maxAvailable"></span> <span x-text="selectedCurrency"></span>
                    </p>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">اسم البنك / المصرف *</label>
                    <input type="text" name="bank_name" required placeholder="مثال: مصرف الراجحي / البنك الأهلي السعودي"
                           class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">اسم صاحب الحساب (المستفيد) *</label>
                    <input type="text" name="account_holder_name" required placeholder="الاسم المطابق لبطاقة الحساب البنكي"
                           class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">رقم الآيبان (IBAN) أو رقم الحساب *</label>
                    <input type="text" name="account_reference" required placeholder="SA0000000000000000000000"
                           class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-mono focus:ring-2 focus:ring-teal-500 focus:outline-none dir-ltr text-right">
                    <p class="text-[10px] text-slate-400 mt-1">يتم تشفير وتظليل رقم الحساب تلقائياً في السجلات العامة لحماية خصوصيتك المصرفية.</p>
                </div>

                <div class="bg-amber-50 border border-amber-200/80 rounded-2xl p-3 text-[11px] text-amber-800 space-y-1">
                    <p class="font-bold">⚠️ تنبيه أمني وإجرائي:</p>
                    <p>عند تأكيد الطلب، سيتم حجز المبلغ فورياً من رصيدك المتاح لمنع ازدواجية الصرف، وستتم مراجعته والتحويل لحسابك خلال يومين عمل.</p>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    <button type="button" @click="payoutModalOpen = false"
                            class="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition cursor-pointer">
                        إلغاء
                    </button>
                    <button type="submit"
                            class="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black shadow-md transition cursor-pointer">
                        تأكيد وإرسال طلب السحب
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Payout Requests History -->
    <div class="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h3 class="text-base font-black text-slate-900">سجل طلبات سحب الأرباح (Payout Requests)</h3>
                <p class="text-xs text-slate-500 mt-0.5">متابعة حالات طلبات السحب المصرفي الخاصة بك</p>
            </div>
        </div>

        @if ($payoutRequests->isEmpty())
            <div class="p-12 text-center text-slate-400 text-xs">
                لم تقم بتقديم أي طلبات سحب أرباح حتى الآن. عند تقديم أول طلب سحب سيظهر سجله هنا مباشرة.
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-right text-xs">
                    <thead class="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                        <tr>
                            <th class="p-4">رقم الطلب</th>
                            <th class="p-4">المبلغ</th>
                            <th class="p-4">البنك / الحساب المظلل</th>
                            <th class="p-4">الحالة</th>
                            <th class="p-4">مرجع التحويل البنكي</th>
                            <th class="p-4">تاريخ الطلب</th>
                            <th class="p-4">ملاحظات</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @foreach ($payoutRequests as $req)
                            <tr class="hover:bg-slate-50/70 transition">
                                <td class="p-4 font-mono font-bold text-slate-900">
                                    {{ $req->request_number }}
                                </td>
                                <td class="p-4 font-black text-slate-900">
                                    {{ \App\Services\Math\MoneyMath::display($req->amount, $req->currency->value) }}
                                    <span class="text-[10px] font-normal text-slate-400">{{ $req->currency->value }}</span>
                                </td>
                                <td class="p-4">
                                    <div class="font-bold text-slate-800">{{ $req->bank_name ?? '—' }}</div>
                                    <div class="font-mono text-[11px] text-slate-500 mt-0.5">{{ $req->account_reference ?? '—' }}</div>
                                </td>
                                <td class="p-4">
                                    <span class="inline-flex px-2.5 py-1 rounded-full text-[10px] font-bold border {{ $req->status->badgeClass() }}">
                                        {{ $req->status->label() }}
                                    </span>
                                </td>
                                <td class="p-4 font-mono text-slate-600">
                                    @if ($req->payment_reference)
                                        <span class="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                            {{ $req->payment_reference }}
                                        </span>
                                    @else
                                        <span class="text-slate-400 italic">بانتظار التحويل</span>
                                    @endif
                                </td>
                                <td class="p-4 font-mono text-[11px] text-slate-500">
                                    {{ $req->created_at->format('Y-m-d H:i') }}
                                </td>
                                <td class="p-4 text-slate-500 max-w-xs truncate">
                                    @if ($req->rejection_reason)
                                        <span class="text-rose-600 font-bold" title="{{ $req->rejection_reason }}">
                                            سبب الرفض: {{ $req->rejection_reason }}
                                        </span>
                                    @elseif ($req->admin_notes)
                                        <span>{{ $req->admin_notes }}</span>
                                    @else
                                        <span class="text-slate-300">—</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="p-4 border-t border-slate-100">
                {{ $payoutRequests->links() }}
            </div>
        @endif
    </div>

    <!-- Commission Settlements History -->
    <div class="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h3 class="text-base font-black text-slate-900">سجل استحقاقات العمولات (Settled Commissions)</h3>
                <p class="text-xs text-slate-500 mt-0.5">العمولات المرحلة في دفتر الأستاذ والمضافة لمحفظتك من تحويلات المبيعات المؤكدة</p>
            </div>
        </div>

        @if ($settlements->isEmpty())
            <div class="p-12 text-center text-slate-400 text-xs">
                لا توجد تسويات عمولات مسجلة بعد. عند اعتماد أي تحويل من قبل العلامات التجارية تضاف أرباحك هنا فوراً.
            </div>
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-right text-xs">
                    <thead class="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                        <tr>
                            <th class="p-4">رقم التحويل الخارجي</th>
                            <th class="p-4">الحملة التسويقية</th>
                            <th class="p-4">قيمة العمولة المستحقة</th>
                            <th class="p-4">تاريخ التسوية</th>
                            <th class="p-4">الحالة المحاسبية</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @foreach ($settlements as $settlement)
                            <tr class="hover:bg-slate-50/70 transition">
                                <td class="p-4 font-mono font-bold text-slate-900">
                                    #{{ $settlement->conversion?->external_order_id ?? '—' }}
                                </td>
                                <td class="p-4 font-bold text-slate-800">
                                    {{ $settlement->conversion?->campaign?->title ?? '—' }}
                                </td>
                                <td class="p-4 font-black text-emerald-600">
                                    +{{ \App\Services\Math\MoneyMath::display($settlement->commission_amount, $settlement->currency->value) }}
                                    <span class="text-[10px] font-normal text-slate-400">{{ $settlement->currency->value }}</span>
                                </td>
                                <td class="p-4 font-mono text-[11px] text-slate-500">
                                    {{ $settlement->settled_at->format('Y-m-d H:i') }}
                                </td>
                                <td class="p-4">
                                    @if ($settlement->isReversed())
                                        <span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                                            معكوس (طلب ملغي)
                                        </span>
                                    @else
                                        <span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                            مرحل في المحفظة ✓
                                        </span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="p-4 border-t border-slate-100">
                {{ $settlements->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
